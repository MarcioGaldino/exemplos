package br.com.hdi.pagfor.valueobject;

import java.sql.Date;

public class ScheduleAutomacao {
	
	
	public ScheduleAutomacao()
	{
		
	}
	
	public ScheduleAutomacao(int cdScheduleAutomacao, String nmArquivo, Date dtSolicitacao, String dsAcao, String stScheduleAutomacao, int nuPrioridade)
	{
		this.cdSchuduleAutomacao = cdScheduleAutomacao;
		this.nmArquivo = nmArquivo;
		this.dtSolicitacao = dtSolicitacao;
		this.dsAcao = dsAcao;
		this.stScheduleAutomacao = stScheduleAutomacao;
		this.nuPrioridade = nuPrioridade; 
	}
	
	private int cdSchuduleAutomacao;
	private String nmArquivo;
	private Date dtSolicitacao;
	private String dsAcao;
	private String stScheduleAutomacao;
	private int nuPrioridade;
	private String nmScriptFTPClient;
	
	
	public String getNmScriptFTPClient() {
		return nmScriptFTPClient;
	}

	public void setNmScriptFTPClient(String nmScriptFTPClient) {
		this.nmScriptFTPClient = nmScriptFTPClient;
	}

	public int getCdSchuduleAutomacao() {
		return cdSchuduleAutomacao;
	}

	public void setCdSchuduleAutomacao(int cdSchuduleAutomacao) {
		this.cdSchuduleAutomacao = cdSchuduleAutomacao;
	}

	public String getNmArquivo() {
		return nmArquivo;
	}

	public void setNmArquivo(String nmArquivo) {
		this.nmArquivo = nmArquivo;
	}

	public Date getDtSolicitacao() {
		return dtSolicitacao;
	}

	public void setDtSolicitacao(Date dtSolicitacao) {
		this.dtSolicitacao = dtSolicitacao;
	}

	public String getDsAcao() {
		return dsAcao;
	}

	public void setDsAcao(String dsAcao) {
		this.dsAcao = dsAcao;
	}

	public String getStScheduleAutomacao() {
		return stScheduleAutomacao;
	}

	public void setStScheduleAutomacao(String stScheduleAutomacao) {
		this.stScheduleAutomacao = stScheduleAutomacao;
	}

	public int getNuPrioridade() {
		return nuPrioridade;
	}

	public void setNuPrioridade(int nuPrioridade) {
		this.nuPrioridade = nuPrioridade;
	}

	

}
