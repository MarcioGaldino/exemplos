package br.com.hdi.pagfor.valueobject;

public class BradescoHeaderValueObject {
	
	
	public BradescoHeaderValueObject()
	{
		
	}
	
	public BradescoHeaderValueObject
	(
		String ID_NOME_ARQUIVO, 
		int COD_REG,
		Double COD_COMUN,
		int TIP_INSC,
		String CGC_CPF,
		String RAZAO_SOCIAL,
		int TIP_SERV,
		int COD_ORIGEM,
		int NRO_REMESSA,
		int NRO_RETORNO,
		String DAT_GRAVA,
		String HRS_GRAVA,
		String FILLER1,
		int TIP_PROC,
		String TIP_ARQ,
		String USO_EMPRESA,
		String FILLER2,
		int HDI_SEQ
	)
	{
		this.ID_NOME_ARQUIVO = ID_NOME_ARQUIVO;
		this.TIP_INSC = TIP_INSC;
		 this.CGC_CPF = CGC_CPF;
		 this.RAZAO_SOCIAL = RAZAO_SOCIAL;
		 this.TIP_SERV = TIP_SERV;
		 this.COD_ORIGEM = COD_ORIGEM;
		 this.NRO_REMESSA = NRO_REMESSA;
		 this.NRO_RETORNO = NRO_RETORNO;
		 this.DAT_GRAVA = DAT_GRAVA;
		 this.HRS_GRAVA = HRS_GRAVA;
		 this.FILLER1 = FILLER1;
		 this.TIP_PROC = TIP_PROC;
		 this.TIP_ARQ = TIP_ARQ;
		 this.USO_EMPRESA = USO_EMPRESA;
		 this.FILLER2 = FILLER2;
		 this.HDI_SEQ = HDI_SEQ;
	}
	
	
	public String getID_NOME_ARQUIVO() {
		return ID_NOME_ARQUIVO;
	}
	public void setID_NOME_ARQUIVO(String iD_NOME_ARQUIVO) {
		ID_NOME_ARQUIVO = iD_NOME_ARQUIVO;
	}
	public int getCOD_REG() {
		return COD_REG;
	}
	public void setCOD_REG(int cOD_REG) {
		COD_REG = cOD_REG;
	}
	public Double getCOD_COMUN() {
		return COD_COMUN != null ? COD_COMUN: 0;
	}
	public void setCOD_COMUN(Double cOD_COMUN) {
		COD_COMUN = cOD_COMUN;
	}
	public int getTIP_INSC() {
		return TIP_INSC;
	}
	public void setTIP_INSC(int tIP_INSC) {
		TIP_INSC = tIP_INSC;
	}
	public String getCGC_CPF() {
		return CGC_CPF;
	}
	public void setCGC_CPF(String cGC_CPF) {
		CGC_CPF = cGC_CPF;
	}
	public String getRAZAO_SOCIAL() {
		return RAZAO_SOCIAL;
	}
	public void setRAZAO_SOCIAL(String rAZAO_SOCIAL) {
		RAZAO_SOCIAL = rAZAO_SOCIAL;
	}
	public int getTIP_SERV() {
		return TIP_SERV;
	}
	public void setTIP_SERV(int tIP_SERV) {
		TIP_SERV = tIP_SERV;
	}
	public int getCOD_ORIGEM() {
		return COD_ORIGEM;
	}
	public void setCOD_ORIGEM(int cOD_ORIGEM) {
		COD_ORIGEM = cOD_ORIGEM;
	}
	public int getNRO_REMESSA() {
		return NRO_REMESSA;
	}
	public void setNRO_REMESSA(int nRO_REMESSA) {
		NRO_REMESSA = nRO_REMESSA;
	}
	public int getNRO_RETORNO() {
		return NRO_RETORNO;
	}
	public void setNRO_RETORNO(int nRO_RETORNO) {
		NRO_RETORNO = nRO_RETORNO;
	}
	public String getDAT_GRAVA() {
		return DAT_GRAVA;
	}
	public void setDAT_GRAVA(String dAT_GRAVA) {
		DAT_GRAVA = dAT_GRAVA;
	}
	public String getHRS_GRAVA() {
		return HRS_GRAVA;
	}
	public void setHRS_GRAVA(String hRS_GRAVA) {
		HRS_GRAVA = hRS_GRAVA;
	}
	public String getFILLER1() {
		return FILLER1;
	}
	public void setFILLER1(String fILLER1) {
		FILLER1 = fILLER1;
	}
	public int getTIP_PROC() {
		return TIP_PROC;
	}
	public void setTIP_PROC(int tIP_PROC) {
		TIP_PROC = tIP_PROC;
	}
	public String getTIP_ARQ() {
		return TIP_ARQ;
	}
	public void setTIP_ARQ(String tIP_ARQ) {
		TIP_ARQ = tIP_ARQ;
	}
	public String getUSO_EMPRESA() {
		return USO_EMPRESA;
	}
	public void setUSO_EMPRESA(String uSO_EMPRESA) {
		USO_EMPRESA = uSO_EMPRESA;
	}
	public String getFILLER2() {
		return FILLER2;
	}
	public void setFILLER2(String fILLER2) {
		FILLER2 = fILLER2;
	}
	public int getHDI_SEQ() {
		return HDI_SEQ;
	}
	public void setHDI_SEQ(int hDI_SEQ) {
		HDI_SEQ = hDI_SEQ;
	}
	private String ID_NOME_ARQUIVO;
    private int COD_REG;
    private Double COD_COMUN;
    private int TIP_INSC;
    private String CGC_CPF;
    private String RAZAO_SOCIAL;
    private int TIP_SERV;
    private int COD_ORIGEM;
    private int NRO_REMESSA;
    private int NRO_RETORNO;
    private String DAT_GRAVA;
    private String HRS_GRAVA;
    private String FILLER1;
    private int TIP_PROC;
    private String TIP_ARQ;
    private String USO_EMPRESA;
    private String FILLER2;
    private int HDI_SEQ;
	

}
