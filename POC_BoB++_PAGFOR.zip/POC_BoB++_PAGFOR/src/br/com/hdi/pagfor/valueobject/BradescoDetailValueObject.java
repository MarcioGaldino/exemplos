package br.com.hdi.pagfor.valueobject;

public class BradescoDetailValueObject {
	
	
	public BradescoDetailValueObject()
	{
		
	}
	
	public BradescoDetailValueObject(
			
			String ID_NOME_ARQUIVO,
			int COD_REG,
			int TIP_INSC,
			String CGC_CPF,
			String RAZAO_SOCIAL,
			String ENDERECO,
			String DT1_CEP,
			String DT1_COMPL_CEP,
			int DT1_BCO,
			int COD_AGE,
			int DIG_AGE,
			String NRO_CTA,
			String DIG_CTO,
			String NRO_PAGTO,
			int CARTEIRA,
			int NOSSO_NRO1,
			double NOSSO_NRO2,
			String SEU_NRO,
			String FILLER1,
			String DAT_VENCTO,
			String DAT_EMISSAO,
			String LIM_DESCTO,
			String VLR_DOCTO,
			String VLR_PAGTO,
			String VLR_DESCTO,
			String VLR_ACRESCIMO,
			String TIP_DOCTO,
			String NRO_NOTA,
			String SERIE_DOCTO,
			int MOD_PAGTO,
			String DAT_EFET_PAGTO,
			String FILLER2,
			int SET_RETORNO,
			String MSG_RETORNO,
			int TIP_MOVTO,
			int COD_MOVTO,
			String FILLER,
			int COD_AREA,
			String FILLER4,
			String FILLER5,
			int DT1_COD_ARQ,
			String FILLER6,
			int DT1_TIP_CTA,
			double DT1_CTA_COMPL,
			String FILLER7,
			int DT1_SEQ
		)
	{
		
		this.ID_NOME_ARQUIVO	=	ID_NOME_ARQUIVO	;
		this.COD_REG	=	COD_REG	;
		this.TIP_INSC	=	TIP_INSC	;
		this.CGC_CPF	=	CGC_CPF	;
		this.RAZAO_SOCIAL	=	RAZAO_SOCIAL	;
		this.ENDERECO	=	ENDERECO	;
		this.DT1_CEP	=	DT1_CEP	;
		this.DT1_COMPL_CEP	=	DT1_COMPL_CEP	;
		this.DT1_BCO	=	DT1_BCO	;
		this.COD_AGE	=	COD_AGE	;
		this.DIG_AGE	=	DIG_AGE	;
		this.NRO_CTA	=	NRO_CTA	;
		this.DIG_CTO	=	DIG_CTO	;
		this.NRO_PAGTO	=	NRO_PAGTO	;
		this.CARTEIRA	=	CARTEIRA	;
		this.NOSSO_NRO1	=	NOSSO_NRO1	;
		this.NOSSO_NRO2	=	NOSSO_NRO2	;
		this.SEU_NRO	=	SEU_NRO	;
		this.FILLER1	=	FILLER1	;
		this.DAT_VENCTO	=	DAT_VENCTO	;
		this.DAT_EMISSAO	=	DAT_EMISSAO	;
		this.LIM_DESCTO	=	LIM_DESCTO	;
		this.VLR_DOCTO	=	VLR_DOCTO	;
		this.VLR_PAGTO	=	VLR_PAGTO	;
		this.VLR_DESCTO	=	VLR_DESCTO	;
		this.VLR_ACRESCIMO	=	VLR_ACRESCIMO	;
		this.TIP_DOCTO	=	TIP_DOCTO	;
		this.NRO_NOTA	=	NRO_NOTA	;
		this.SERIE_DOCTO	=	SERIE_DOCTO	;
		this.MOD_PAGTO	=	MOD_PAGTO	;
		this.DAT_EFET_PAGTO	=	DAT_EFET_PAGTO	;
		this.FILLER2	=	FILLER2	;
		this.SET_RETORNO	=	SET_RETORNO	;
		this.MSG_RETORNO	=	MSG_RETORNO	;
		this.TIP_MOVTO	=	TIP_MOVTO	;
		this.COD_MOVTO	=	COD_MOVTO	;
		this.FILLER	=	FILLER	;
		this.COD_AREA	=	COD_AREA	;
		this.FILLER4	=	FILLER4	;
		this.FILLER5	=	FILLER5	;
		this.DT1_COD_ARQ	=	DT1_COD_ARQ	;
		this.FILLER6	=	FILLER6	;
		this.DT1_TIP_CTA	=	DT1_TIP_CTA	;
		this.DT1_CTA_COMPL	=	DT1_CTA_COMPL	;
		this.FILLER7	=	FILLER7	;
		this.DT1_SEQ	=	DT1_SEQ	;
	}
	
	
	public String getID_NOME_ARQUIVO() {
		return ID_NOME_ARQUIVO;
	}
	public void setID_NOME_ARQUIVO(String iD_NOME_ARQUIVO) {
		ID_NOME_ARQUIVO = iD_NOME_ARQUIVO;
	}
	public int getCOD_REG() {
		return COD_REG;
	}
	public void setCOD_REG(int cOD_REG) {
		COD_REG = cOD_REG;
	}
	public int getTIP_INSC() {
		return TIP_INSC;
	}
	public void setTIP_INSC(int tIP_INSC) {
		TIP_INSC = tIP_INSC;
	}
	public String getCGC_CPF() {
		return CGC_CPF;
	}
	public void setCGC_CPF(String cGC_CPF) {
		CGC_CPF = cGC_CPF;
	}
	public String getRAZAO_SOCIAL() {
		return RAZAO_SOCIAL;
	}
	public void setRAZAO_SOCIAL(String rAZAO_SOCIAL) {
		RAZAO_SOCIAL = rAZAO_SOCIAL;
	}
	public String getENDERECO() {
		return ENDERECO;
	}
	public void setENDERECO(String eNDERECO) {
		ENDERECO = eNDERECO;
	}
	public String getDT1_CEP() {
		return DT1_CEP;
	}
	public void setDT1_CEP(String dT1_CEP) {
		DT1_CEP = dT1_CEP;
	}
	public String getDT1_COMPL_CEP() {
		return DT1_COMPL_CEP;
	}
	public void setDT1_COMPL_CEP(String dT1_COMPL_CEP) {
		DT1_COMPL_CEP = dT1_COMPL_CEP;
	}
	public int getDT1_BCO() {
		return DT1_BCO;
	}
	public void setDT1_BCO(int dT1_BCO) {
		DT1_BCO = dT1_BCO;
	}
	public int getCOD_AGE() {
		return COD_AGE;
	}
	public void setCOD_AGE(int cOD_AGE) {
		COD_AGE = cOD_AGE;
	}
	public int getDIG_AGE() {
		return DIG_AGE;
	}
	public void setDIG_AGE(int dIG_AGE) {
		DIG_AGE = dIG_AGE;
	}
	public String getNRO_CTA() {
		return NRO_CTA;
	}
	public void setNRO_CTA(String nRO_CTA) {
		NRO_CTA = nRO_CTA;
	}
	public String getDIG_CTO() {
		return DIG_CTO;
	}
	public void setDIG_CTO(String dIG_CTO) {
		DIG_CTO = dIG_CTO;
	}
	public String getNRO_PAGTO() {
		return NRO_PAGTO;
	}
	public void setNRO_PAGTO(String nRO_PAGTO) {
		NRO_PAGTO = nRO_PAGTO;
	}
	public int getCARTEIRA() {
		return CARTEIRA;
	}
	public void setCARTEIRA(int cARTEIRA) {
		CARTEIRA = cARTEIRA;
	}
	public int getNOSSO_NRO1() {
		return NOSSO_NRO1;
	}
	public void setNOSSO_NRO1(int nOSSO_NRO1) {
		NOSSO_NRO1 = nOSSO_NRO1;
	}
	public double getNOSSO_NRO2() {
		return NOSSO_NRO2;
	}
	public void setNOSSO_NRO2(double nOSSO_NRO2) {
		NOSSO_NRO2 = nOSSO_NRO2;
	}
	public String getSEU_NRO() {
		return SEU_NRO;
	}
	public void setSEU_NRO(String sEU_NRO) {
		SEU_NRO = sEU_NRO;
	}
	public String getFILLER1() {
		return FILLER1;
	}
	public void setFILLER1(String fILLER1) {
		FILLER1 = fILLER1;
	}
	public String getDAT_VENCTO() {
		return DAT_VENCTO;
	}
	public void setDAT_VENCTO(String dAT_VENCTO) {
		DAT_VENCTO = dAT_VENCTO;
	}
	public String getDAT_EMISSAO() {
		return DAT_EMISSAO;
	}
	public void setDAT_EMISSAO(String dAT_EMISSAO) {
		DAT_EMISSAO = dAT_EMISSAO;
	}
	public String getLIM_DESCTO() {
		return LIM_DESCTO;
	}
	public void setLIM_DESCTO(String lIM_DESCTO) {
		LIM_DESCTO = lIM_DESCTO;
	}
	public String getVLR_DOCTO() {
		return VLR_DOCTO;
	}
	public void setVLR_DOCTO(String vLR_DOCTO) {
		VLR_DOCTO = vLR_DOCTO;
	}
	public String getVLR_PAGTO() {
		return VLR_PAGTO;
	}
	public void setVLR_PAGTO(String vLR_PAGTO) {
		VLR_PAGTO = vLR_PAGTO;
	}
	public String getVLR_DESCTO() {
		return VLR_DESCTO;
	}
	public void setVLR_DESCTO(String vLR_DESCTO) {
		VLR_DESCTO = vLR_DESCTO;
	}
	public String getVLR_ACRESCIMO() {
		return VLR_ACRESCIMO;
	}
	public void setVLR_ACRESCIMO(String vLR_ACRESCIMO) {
		VLR_ACRESCIMO = vLR_ACRESCIMO;
	}
	public String getTIP_DOCTO() {
		return TIP_DOCTO;
	}
	public void setTIP_DOCTO(String tIP_DOCTO) {
		TIP_DOCTO = tIP_DOCTO;
	}
	public String getNRO_NOTA() {
		return NRO_NOTA;
	}
	public void setNRO_NOTA(String nRO_NOTA) {
		NRO_NOTA = nRO_NOTA;
	}
	public String getSERIE_DOCTO() {
		return SERIE_DOCTO;
	}
	public void setSERIE_DOCTO(String sERIE_DOCTO) {
		SERIE_DOCTO = sERIE_DOCTO;
	}
	public int getMOD_PAGTO() {
		return MOD_PAGTO;
	}
	public void setMOD_PAGTO(int mOD_PAGTO) {
		MOD_PAGTO = mOD_PAGTO;
	}
	public String getDAT_EFET_PAGTO() {
		return DAT_EFET_PAGTO;
	}
	public void setDAT_EFET_PAGTO(String dAT_EFET_PAGTO) {
		DAT_EFET_PAGTO = dAT_EFET_PAGTO;
	}
	public String getFILLER2() {
		return FILLER2;
	}
	public void setFILLER2(String fILLER2) {
		FILLER2 = fILLER2;
	}
	public int getSET_RETORNO() {
		return SET_RETORNO;
	}
	public void setSET_RETORNO(int sET_RETORNO) {
		SET_RETORNO = sET_RETORNO;
	}
	public String getMSG_RETORNO() {
		return MSG_RETORNO;
	}
	public void setMSG_RETORNO(String mSG_RETORNO) {
		MSG_RETORNO = mSG_RETORNO;
	}
	public int getTIP_MOVTO() {
		return TIP_MOVTO;
	}
	public void setTIP_MOVTO(int tIP_MOVTO) {
		TIP_MOVTO = tIP_MOVTO;
	}
	public int getCOD_MOVTO() {
		return COD_MOVTO;
	}
	public void setCOD_MOVTO(int cOD_MOVTO) {
		COD_MOVTO = cOD_MOVTO;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public int getCOD_AREA() {
		return COD_AREA;
	}
	public void setCOD_AREA(int cOD_AREA) {
		COD_AREA = cOD_AREA;
	}
	public String getFILLER4() {
		return FILLER4;
	}
	public void setFILLER4(String fILLER4) {
		FILLER4 = fILLER4;
	}
	public String getFILLER5() {
		return FILLER5;
	}
	public void setFILLER5(String fILLER5) {
		FILLER5 = fILLER5;
	}
	public int getDT1_COD_ARQ() {
		return DT1_COD_ARQ;
	}
	public void setDT1_COD_ARQ(int dT1_COD_ARQ) {
		DT1_COD_ARQ = dT1_COD_ARQ;
	}
	public String getFILLER6() {
		return FILLER6;
	}
	public void setFILLER6(String fILLER6) {
		FILLER6 = fILLER6;
	}
	public int getDT1_TIP_CTA() {
		return DT1_TIP_CTA;
	}
	public void setDT1_TIP_CTA(int dT1_TIP_CTA) {
		DT1_TIP_CTA = dT1_TIP_CTA;
	}
	public double getDT1_CTA_COMPL() {
		return DT1_CTA_COMPL;
	}
	public void setDT1_CTA_COMPL(double dT1_CTA_COMPL) {
		DT1_CTA_COMPL = dT1_CTA_COMPL;
	}
	public String getFILLER7() {
		return FILLER7;
	}
	public void setFILLER7(String fILLER7) {
		FILLER7 = fILLER7;
	}
	public int getDT1_SEQ() {
		return DT1_SEQ;
	}
	public void setDT1_SEQ(int dT1_SEQ) {
		DT1_SEQ = dT1_SEQ;
	}
	private String ID_NOME_ARQUIVO;
	private int COD_REG;
	private int TIP_INSC;
	private String CGC_CPF;
	private String RAZAO_SOCIAL;
	private String ENDERECO;
	private String DT1_CEP;
	private String DT1_COMPL_CEP;
	private int DT1_BCO;
	private int COD_AGE;
	private int DIG_AGE;
	private String NRO_CTA;
	private String DIG_CTO;
	private String NRO_PAGTO;
	private int CARTEIRA;
	private int NOSSO_NRO1;
	private double NOSSO_NRO2;
	private String SEU_NRO;
	private String FILLER1;
	private String DAT_VENCTO;
	private String DAT_EMISSAO;
	private String LIM_DESCTO;
	private String VLR_DOCTO;
	private String VLR_PAGTO;
	private String VLR_DESCTO;
	private String VLR_ACRESCIMO;
	private String TIP_DOCTO;
	private String NRO_NOTA;
	private String SERIE_DOCTO;
	private int MOD_PAGTO;
	private String DAT_EFET_PAGTO;
	private String FILLER2;
	private int SET_RETORNO;
	private String MSG_RETORNO;
	private int TIP_MOVTO;
	private int COD_MOVTO;
	private String FILLER;
	private int COD_AREA;
	private String FILLER4;
	private String FILLER5;
	private int DT1_COD_ARQ;
	private String FILLER6;
	private int DT1_TIP_CTA;
	private double DT1_CTA_COMPL;
	private String FILLER7;
	private int DT1_SEQ;
}
