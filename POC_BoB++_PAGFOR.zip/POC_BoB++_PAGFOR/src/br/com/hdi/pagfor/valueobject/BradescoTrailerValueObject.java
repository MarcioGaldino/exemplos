package br.com.hdi.pagfor.valueobject;

public class BradescoTrailerValueObject {
	
	public BradescoTrailerValueObject()
	{
		
	}
	
	public BradescoTrailerValueObject
	(
			String ID_NOME_ARQUIVO, 
			int COD_REG, 
			int QTDE_REG,
			String VLR_TOTAL,
			String FILLER,
			int SEQ
	)
	{
		this.ID_NOME_ARQUIVO = ID_NOME_ARQUIVO;
		this.COD_REG = COD_REG;
		this.QTDE_REG = QTDE_REG;
		this.VLR_TOTAL = VLR_TOTAL;
		this.FILLER = FILLER;
		this.SEQ = SEQ;
	}
	
	public String getID_NOME_ARQUIVO() {
		return ID_NOME_ARQUIVO;
	}
	public void setID_NOME_ARQUIVO(String iD_NOME_ARQUIVO) {
		ID_NOME_ARQUIVO = iD_NOME_ARQUIVO;
	}
	public int getCOD_REG() {
		return COD_REG;
	}
	public void setCOD_REG(int cOD_REG) {
		COD_REG = cOD_REG;
	}
	public int getQTDE_REG() {
		return QTDE_REG;
	}
	public void setQTDE_REG(int qTDE_REG) {
		QTDE_REG = qTDE_REG;
	}
	public String getVLR_TOTAL() {
		return VLR_TOTAL;
	}
	public void setVLR_TOTAL(String vLR_TOTAL) {
		VLR_TOTAL = vLR_TOTAL;
	}
	public String getFILLER() {
		return FILLER;
	}
	public void setFILLER(String fILLER) {
		FILLER = fILLER;
	}
	public int getSEQ() {
		return SEQ;
	}
	public void setSEQ(int sEQ) {
		SEQ = sEQ;
	}
	private String ID_NOME_ARQUIVO;
	private int COD_REG;
	private int QTDE_REG;
	private String VLR_TOTAL;
	private String FILLER;
	private int SEQ;

}
