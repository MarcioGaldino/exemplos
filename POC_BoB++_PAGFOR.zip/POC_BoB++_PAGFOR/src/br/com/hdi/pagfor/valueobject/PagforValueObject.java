package br.com.hdi.pagfor.valueobject;

public class PagforValueObject {
	
	
	public PagforValueObject()
	{
		
	}
	
	public PagforValueObject(int id, String nomeArquivo, int numeroVersaoArquivo, String diretorioArquivo)
	{
		this.id = id;
		this.nomeArquivo = nomeArquivo;
		this.numeroVersaoArquivo = numeroVersaoArquivo;
		this.diretorioArquivo = diretorioArquivo;
	}
	
	private int id;
	private String nomeArquivo;
	private int numeroVersaoArquivo;
	private String diretorioArquivo;
	
	public int getID() {
		return id;
	}
	public void setID(int iD) {
		id = iD;
	}
	public String getNomeArquivo() {
		return nomeArquivo;
	}
	public void setNomeArquivo(String nomeArquivo) {
		nomeArquivo = nomeArquivo;
	}
	public int getNumeroVersaoArquivo() {
		return numeroVersaoArquivo;
	}
	public void setNumeroVersaoArquivo(int numeroVersaoArquivo) {
		numeroVersaoArquivo = numeroVersaoArquivo;
	}
	public String getDiretorioArquivo() {
		return diretorioArquivo;
	}
	public void setDiretorioArquivo(String diretorioArquivo) {
		diretorioArquivo = diretorioArquivo;
	}
	
	
	
	

}
