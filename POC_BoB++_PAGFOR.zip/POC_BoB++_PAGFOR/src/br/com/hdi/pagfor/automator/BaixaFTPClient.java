package br.com.hdi.pagfor.automator;

import java.util.*;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Screen;


/*Repository*/
import br.com.hdi.pagfor.repository.ComprarPagforBradescoDebitoCredito;
import br.com.hdi.pagfor.valueobject.BradescoDetailValueObject;
import br.com.hdi.pagfor.valueobject.BradescoHeaderValueObject;
import br.com.hdi.pagfor.valueobject.BradescoTrailerValueObject;
import br.com.hdi.pagfor.valueobject.PagforValueObject;
import br.com.hdi.pagfor.valueobject.ScheduleAutomacao;

public class BaixaFTPClient {
	
	public Boolean BaixarArquivosFTP(String nmScriptFTP) throws InterruptedException, FindFailed
	{
		ComprarPagforBradescoDebitoCredito bradesco = new ComprarPagforBradescoDebitoCredito();
		try
		{
			Screen screen = new Screen();
			
			Thread.sleep(1000);
			screen.click("C:\\Users\\t2108mrc\\Desktop\\Imagens\\AreaTrabalho.PNG");

			Thread.sleep(1000);
			screen.doubleClick("C:\\Users\\t2108mrc\\Desktop\\Imagens\\windows.PNG");
			Thread.sleep(4000);
			screen.click("C:\\Users\\t2108mrc\\Desktop\\Imagens\\conectar.PNG");
			Thread.sleep(10000);
		
			
			screen.type("C:\\Users\\t2108mrc\\Desktop\\Imagens\\password.PNG", "bili2611");
			Thread.sleep(1000);
			screen.click("C:\\Users\\t2108mrc\\Desktop\\Imagens\\Okpassword.PNG");
			
			System.out.println("Testando Sikuli");
				
			bradesco.TransacaoSchedule("A", 0, nmScriptFTP, "B");
			
			Thread.sleep(4000);

			return true;
		}
		catch(Exception excp)
		{
			return false;
		}
	}

	public Boolean GerarScript(String caminhoGeracaoArquivo, ArrayList<ScheduleAutomacao> schedule, String diretorioExtracao, String nomeScript) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException
	{
		ComprarPagforBradescoDebitoCredito bradesco = new ComprarPagforBradescoDebitoCredito();
		File arquivo = new File(caminhoGeracaoArquivo);
		try( FileWriter fw = new FileWriter( arquivo ) )
		{
			BufferedWriter bw = new BufferedWriter(fw);             
			bw.write("SET QUIET-STATUS YES");
			bw.newLine();
			bw.write( "SET ABORT-ON-ERROR NO");
			bw.newLine();
			bw.write( "continue on");
			bw.newLine();
			bw.newLine();
			bw.write("LCD " + diretorioExtracao);
			bw.newLine();

			for (Iterator<ScheduleAutomacao> iterator = schedule.iterator(); iterator.hasNext(); ) 
			{
			   ScheduleAutomacao  scheduleAutomacao = iterator.next();
			   bw.write( "MGET " + scheduleAutomacao.getNmArquivo() + "(0)");
			   bw.newLine();
			   System.out.println(scheduleAutomacao.getNmArquivo());
			   
			   bradesco.TransacaoSchedule("U", scheduleAutomacao.getCdSchuduleAutomacao(), nomeScript, "G");
			}
		  
			bw.flush();  
			return true;
		}
		catch(IOException ex){
		  ex.printStackTrace();
		  return null;
		}
	}
	
	
	@SuppressWarnings("unused")
	public Boolean InserirArquivoSqlServer(String diretorio) throws FileNotFoundException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException
	{
		
		ArrayList<BradescoTrailerValueObject> trailer = new ArrayList<BradescoTrailerValueObject>();
	 	ArrayList<BradescoHeaderValueObject> header = new ArrayList<BradescoHeaderValueObject>();
		ArrayList<BradescoDetailValueObject> detail = new ArrayList<BradescoDetailValueObject>();
		
		ComprarPagforBradescoDebitoCredito bradesco = new ComprarPagforBradescoDebitoCredito();
		
		
		File file = new File(diretorio);
		File afile[] = file.listFiles();
		int i = 0;
		for (int j = afile.length; i < j; i++) 
		{
			File arquivo = afile[i];
			
			if(afile[i].getName().endsWith("txt"))
			{
			    Scanner sc = new Scanner(new FileReader(arquivo));
			    while (sc.hasNextLine()) 
			    {
			        String line = sc.nextLine();
			        
			        int tipoRegistro = Integer.valueOf(line.substring(0,1));
			        
			        int tamanhoLinha = line.length();
			        
			        //Header
			        if(tipoRegistro == 0)
			        {
			        	header.add(new BradescoHeaderValueObject
			        	(
			        			arquivo.getName(),
			        			Integer.valueOf(line.substring(0,1)),
			        			Double.valueOf(line.substring(1,9)),
			        			Integer.valueOf(line.substring(9,10)),
			        			line.substring(10,25),
			        			line.substring(25,65),
			        			Integer.valueOf(line.substring(65,67)),
			        			Integer.valueOf(line.substring(67,68)),
			        			Integer.valueOf(line.substring(68,73)),
			        			Integer.valueOf(line.substring(73,78)),
			        			line.substring(78,86),
			        			line.substring(86,92),
			        			line.substring(92,105),
			        			Integer.valueOf(line.substring(105,106)),
			        			line.substring(106,109),
			        			line.substring(109,180),
			        			line.substring(180,494),
			        			Integer.valueOf(line.substring(494,500))
			        	));
			        	

			        	System.out.println("PREENCHIDO HEADER");
			        }
			        //Detail
			        else if(tipoRegistro == 1)
			        {
			        	
			        	detail.add(new BradescoDetailValueObject
			        	(
				        	arquivo.getName(),
				        	Integer.valueOf(line.substring(0,1)),
				        	Integer.valueOf(line.substring(1,2)),
				        	line.substring(2,17),
				        	line.substring(17,47),
				        	line.substring(47,87),
				        	line.substring(87,92),
				        	line.substring(92,95),
				        	Integer.valueOf(line.substring(95,98)),
				        	Integer.valueOf(line.substring(98,103)),
				        	Integer.valueOf(line.substring(103,104)),
				        	line.substring(104,117),
				        	line.substring(117,119),
				        	line.substring(119,135),
				        	Integer.valueOf(line.substring(135,138)),
				        	Integer.valueOf(line.substring(138,141)),
				        	Integer.valueOf(line.substring(141,150)),
				        	line.substring(150,164),
				        	line.substring(164,165),
				        	line.substring(165,173),
				        	line.substring(173,181),
				        	line.substring(181,189),
				        	line.substring(189,204),
				        	line.substring(204,219),
				        	line.substring(219,234),
				        	line.substring(234,249),
				        	line.substring(249,251),
				        	line.substring(251,261),
				        	line.substring(261,263),
				        	Integer.valueOf(line.substring(263,265)),
				        	line.substring(265,273),
				        	line.substring(273,276),
				        	Integer.valueOf(line.substring(276,278)),
				        	line.substring(278,288),
				        	Integer.valueOf(line.substring(288,289)),
				        	Integer.valueOf(line.substring(289,291)),
				        	line.substring(291,413),
				        	Integer.valueOf(line.substring(413,415)),
				        	line.substring(415,450),
				        	line.substring(450,472),
				        	Integer.valueOf(line.substring(472,477)),
				        	line.substring(477,478),
				        	Integer.valueOf(line.substring(478,479)),
				        	Integer.valueOf(line.substring(479,486)),
				        	line.substring(486,494),
				        	Integer.valueOf(line.substring(494)) 	
						));

			        	System.out.println("DETAIL");
			        }
			        //Trailer
			        else if(tipoRegistro == 9)
			        {
			        	
			        	trailer.add(new BradescoTrailerValueObject 
			        	(
			        			arquivo.getName(),
					        	Integer.valueOf(line.substring(0,1)),
					        	Integer.valueOf(line.substring(1,7)),
					        	line.substring(7,24),
					        	line.substring(24,494),
					        	Integer.valueOf(line.substring(494))
			        	));
			        	
			        	
			        	System.out.println("TRAILER");	
			        }
			        
			        System.out.println(line.toString());
			    }
			    sc.close();
			}
		}
		
		bradesco.InsereHeader(header);
	    bradesco.InsereDetail(detail);
	    bradesco.insereTrailer(trailer);
		
		return true;
		
	}
}
