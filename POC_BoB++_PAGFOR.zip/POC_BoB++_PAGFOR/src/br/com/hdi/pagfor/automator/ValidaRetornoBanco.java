package br.com.hdi.pagfor.automator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ValidaRetornoBanco {
	
	public Connection cnx;
	 
	public void ConectSqlServer() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException
	{
        String url;
        String portNumber = "1433";
        String userName   = "";
        String passName   = "";
        String host = "";
        String database = "";
        
        Statement st;
        ResultSet rs;
        
//        user=sa;password=Cielo2017;
        
		String dbConnectionStringPrivate = "jdbc:sqlserver://ALPF-DL-L1CB19G\\SERVER_01:1433;databaseName=STARC;";
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
		cnx = DriverManager.getConnection(dbConnectionStringPrivate,"sa", "Cielo2017");
		
        System.out.println("Conex�o obtida com sucesso.");
        
//        this.cnx = DriverManager.getConnection(dbConnectionStringPrivate,"sa", "Cielo2017");
        
		st = cnx.createStatement();
        rs = st.executeQuery("");
		
	}
	
	

}
