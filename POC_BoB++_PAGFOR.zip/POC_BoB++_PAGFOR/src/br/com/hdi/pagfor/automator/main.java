package br.com.hdi.pagfor.automator;


import br.com.hdi.pagfor.repository.ComprarPagforBradescoDebitoCredito;
import org.sikuli.script.*;
import com.thoughtworks.selenium.Wait;

import java.io.FileNotFoundException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;

import org.bridj.*;
import org.openqa.selenium.*;
import br.com.hdi.pagfor.automator.BaixaFTPClient;
import br.com.hdi.pagfor.repository.*;
import br.com.hdi.pagfor.valueobject.PagforValueObject;
import br.com.hdi.pagfor.valueobject.ScheduleAutomacao;


public class main {

	public static void main(String[] args) throws FindFailed, InterruptedException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, FileNotFoundException {
		
		ComprarPagforBradescoDebitoCredito bradesco = new ComprarPagforBradescoDebitoCredito();
		int C = 0;
		//Diretorio dos arquivo Extraidos do FTP.
		String diretorioScriptsFTP = "C:\\STARC\\Retorno\\";
		
		// Variavel com informa��o do caminho de extracaoArquivo
		String caminhoScriptFTP;
		
		
		/*GERAR ARQUIVO PARA BAIXAR OS ARQUIVOS NO FTP*/
		BaixaFTPClient arquivoBaixa = new BaixaFTPClient();
		
		while(C == 0)
		{
			//Schedule de arquivo a serem baixados 
			ArrayList<ScheduleAutomacao> lstSchedule = new ArrayList<ScheduleAutomacao>();
			
			lstSchedule = bradesco.ListarSchedule();
			
			if (lstSchedule.size() > 0)
			{
				
				DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss"); 
				java.util.Date date = new java.util.Date();
				String dStr = dateFormat.format(date); 
				caminhoScriptFTP = diretorioScriptsFTP + "ArquivoFTPCLient" + dStr + ".rfs";
				
				//arquivoBaixa.GerarScript(caminhoScriptFTP, lstSchedule, diretorioScriptsFTP, "ArquivoFTPCLient" + dStr + ".rfs");
				//arquivoBaixa.BaixarArquivosFTP("ArquivoFTPCLient" + dStr + ".rfs");
				//arquivoBaixa.InserirArquivoSqlServer(diretorioScriptsFTP);
			}
			
			lstSchedule.clear();
			
			Thread.sleep(1000);
		}
		
		
		
		
		
	}
}
