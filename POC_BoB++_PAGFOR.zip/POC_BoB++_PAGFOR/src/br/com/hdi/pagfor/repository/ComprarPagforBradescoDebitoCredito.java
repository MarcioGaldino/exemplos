package br.com.hdi.pagfor.repository;

import br.com.hdi.pagfor.valueobject.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Iterator;

public class ComprarPagforBradescoDebitoCredito {
	
	public Connection cnx;
	private void ConectSqlServer() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException 
	{
		String dbConnectionStringPrivate = "jdbc:sqlserver://ALPF-DL-L1CB19G\\SERVER_01:1433;databaseName=DbAutomacaoPAGFOR;";
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
		cnx = DriverManager.getConnection(dbConnectionStringPrivate,"sa", "Cielo2017");
	}
	
	
	public void InsereHeader(ArrayList<BradescoHeaderValueObject> resource) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException
	{
		Statement statement;
		PreparedStatement prepared;
		
		ConectSqlServer();
		
		try
		{
			statement = cnx.createStatement();
			prepared = cnx.prepareStatement("Exec PrInsereHeaderBradesco ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?");
			prepared.setEscapeProcessing(true);
			
			for (Iterator<BradescoHeaderValueObject> iterator = resource.iterator(); iterator.hasNext(); ) 
			{
				BradescoHeaderValueObject bradescoHeader = iterator.next();
			
				prepared.setString(1,bradescoHeader.getID_NOME_ARQUIVO());
				prepared.setInt(2,bradescoHeader.getCOD_REG());
				prepared.setDouble(3,bradescoHeader.getCOD_COMUN());
				prepared.setInt(4,bradescoHeader.getTIP_INSC());
				prepared.setString(5,bradescoHeader.getCGC_CPF());
				prepared.setString(6,bradescoHeader.getRAZAO_SOCIAL());
				prepared.setInt(7,bradescoHeader.getTIP_SERV());
				prepared.setInt(8,bradescoHeader.getCOD_ORIGEM());
				prepared.setInt(9,bradescoHeader.getNRO_REMESSA());
				prepared.setInt(10,bradescoHeader.getNRO_RETORNO());
				prepared.setString(11,bradescoHeader.getDAT_GRAVA());
				prepared.setString(12,bradescoHeader.getHRS_GRAVA());
				prepared.setString(13,bradescoHeader.getFILLER1());
				prepared.setInt(14,bradescoHeader.getTIP_PROC());
				prepared.setString(15,bradescoHeader.getTIP_ARQ());
				prepared.setString(16,bradescoHeader.getUSO_EMPRESA());
				prepared.setString(17,bradescoHeader.getFILLER2());
				prepared.setInt(18,bradescoHeader.getHDI_SEQ());
				
				prepared.execute();
			}
			
		}
		catch(Exception excp)
		{
			System.out.println(excp);
		}
	}
	
	public void InsereDetail( ArrayList<BradescoDetailValueObject>  resource)
	{
		Statement statement;
		PreparedStatement prepared;
		
		try
		{
			statement = cnx.createStatement();
			prepared = cnx.prepareStatement("Exec PrInsereDetailBradesco ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?");
			prepared.setEscapeProcessing(true);
			
			for (Iterator<BradescoDetailValueObject> iterator = resource.iterator(); iterator.hasNext(); ) 
			{
			   BradescoDetailValueObject bradescoDetail = iterator.next();
			   
			   prepared.setString(1,bradescoDetail.getID_NOME_ARQUIVO());
			   prepared.setInt(2,bradescoDetail.getCOD_REG());
			   prepared.setInt(3,bradescoDetail.getTIP_INSC());
			   prepared.setString(4,bradescoDetail.getCGC_CPF());
			   prepared.setString(5,bradescoDetail.getRAZAO_SOCIAL());
			   prepared.setString(6,bradescoDetail.getENDERECO());
			   prepared.setString(7,bradescoDetail.getDT1_CEP());
			   prepared.setString(8,bradescoDetail.getDT1_COMPL_CEP());
			   prepared.setInt(9,bradescoDetail.getDT1_BCO());
			   prepared.setInt(10,bradescoDetail.getCOD_AGE());
			   prepared.setInt(11,bradescoDetail.getDIG_AGE());
			   prepared.setString(12,bradescoDetail.getNRO_CTA());
			   prepared.setString(13,bradescoDetail.getDIG_CTO());
			   prepared.setString(14,bradescoDetail.getNRO_PAGTO());
			   prepared.setInt(15,bradescoDetail.getCARTEIRA());
			   prepared.setInt(16,bradescoDetail.getNOSSO_NRO1());
			   prepared.setDouble(17,bradescoDetail.getNOSSO_NRO2());
			   prepared.setString(18,bradescoDetail.getSEU_NRO());
			   prepared.setString(19,bradescoDetail.getFILLER1());
			   prepared.setString(20,bradescoDetail.getDAT_VENCTO());
			   prepared.setString(21,bradescoDetail.getDAT_EMISSAO());
			   prepared.setString(22,bradescoDetail.getLIM_DESCTO());
			   prepared.setString(23,bradescoDetail.getVLR_DOCTO());
			   prepared.setString(24,bradescoDetail.getVLR_PAGTO());
			   prepared.setString(25,bradescoDetail.getVLR_DESCTO());
			   prepared.setString(26,bradescoDetail.getVLR_ACRESCIMO());
			   prepared.setString(27,bradescoDetail.getTIP_DOCTO());
			   prepared.setString(28,bradescoDetail.getNRO_NOTA());
			   prepared.setString(29,bradescoDetail.getSERIE_DOCTO());
			   prepared.setInt(30,bradescoDetail.getMOD_PAGTO());
			   prepared.setString(31,bradescoDetail.getDAT_EFET_PAGTO());
			   prepared.setString(32,bradescoDetail.getFILLER2());
			   prepared.setInt(33,bradescoDetail.getSET_RETORNO());
			   prepared.setString(34,bradescoDetail.getMSG_RETORNO());
			   prepared.setInt(35,bradescoDetail.getTIP_MOVTO());
			   prepared.setInt(36,bradescoDetail.getCOD_MOVTO());
			   prepared.setString(37,bradescoDetail.getFILLER());
			   prepared.setInt(38,bradescoDetail.getCOD_AREA());
			   prepared.setString(39,bradescoDetail.getFILLER4());
			   prepared.setString(40,bradescoDetail.getFILLER5());
			   prepared.setInt(41,bradescoDetail.getDT1_COD_ARQ());
			   prepared.setString(42,bradescoDetail.getFILLER6());
			   prepared.setInt(43,bradescoDetail.getDT1_TIP_CTA());
			   prepared.setDouble(44,bradescoDetail.getDT1_CTA_COMPL());
			   prepared.setString(45,bradescoDetail.getFILLER7());
			   prepared.setInt(46,bradescoDetail.getDT1_SEQ());
			   
			   prepared.execute();
			}

		}
		catch(Exception excp)
		{
			System.out.println(excp);
		}
	}
	
	
	public void insereTrailer(ArrayList<BradescoTrailerValueObject> resource)
	{
		Statement statement;
		PreparedStatement prepared;
		
		try
		{
			statement = cnx.createStatement();
			prepared = cnx.prepareStatement("Exec PrInsereTrailerBradesco ?,?,?,?,?,?");
			prepared.setEscapeProcessing(true);
			
			for (Iterator<BradescoTrailerValueObject> iterator = resource.iterator(); iterator.hasNext(); ) 
			{
				BradescoTrailerValueObject bradescoTrailer = iterator.next();
			
				prepared.setString(1,bradescoTrailer.getID_NOME_ARQUIVO());
				prepared.setInt(2,bradescoTrailer.getCOD_REG());
				prepared.setInt(3,bradescoTrailer.getQTDE_REG());
				prepared.setString(4,bradescoTrailer.getVLR_TOTAL());
				prepared.setString(5,bradescoTrailer.getFILLER());
				prepared.setInt(6,bradescoTrailer.getSEQ());
				
				prepared.execute();
			}
		}
		catch(Exception excp)
		{
			System.out.println(excp);
		}
	}
	
	public void TransacaoSchedule(String FlAcao, int cdScheduleAutomacao, String nmAcriptFTPClient, String statusScheduleAutomacao) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException
	{
		Statement statement;
		PreparedStatement prepared;
		ConectSqlServer();
		
		try
		{
			statement = cnx.createStatement();
			prepared = cnx.prepareStatement("Exec PrScheduleAutomacao ?,?,?,?");
			prepared.setEscapeProcessing(true);
			
			prepared.setString(1,FlAcao);
			prepared.setInt(2,cdScheduleAutomacao);
			prepared.setString(3, nmAcriptFTPClient);
			prepared.setString(4, statusScheduleAutomacao);
			prepared.execute();
		}
		catch(Exception excp)
		{
			System.out.println(excp);
		}
		
	}
	
	
	public ArrayList<ScheduleAutomacao> ListarSchedule() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException
	{
		ArrayList<ScheduleAutomacao> schedule = new ArrayList<ScheduleAutomacao>();
		Statement statement;
		ResultSet resultSet;
		ConectSqlServer();
		
		try
		{
			statement = cnx.createStatement();
			resultSet = statement.executeQuery("SELECT * FROM TbScheduleAutomacao WHERE StScheduleAutomacao = 'P' ORDER BY NuPrioridade DESC");
			
			while(resultSet.next())
			{
				schedule.add(new ScheduleAutomacao(
						resultSet.getInt("CdScheduleAutomacao"),
						resultSet.getString("NmArquivo"),
						resultSet.getDate("DtSolicitacao"),
						resultSet.getString("DsAcao"),
						resultSet.getString("StScheduleAutomacao"),
						resultSet.getInt("NuPrioridade")
				));	
			}
			
			return schedule;
		}
		catch(Exception excp)
		{
			return null;
		}
		
	}

}
