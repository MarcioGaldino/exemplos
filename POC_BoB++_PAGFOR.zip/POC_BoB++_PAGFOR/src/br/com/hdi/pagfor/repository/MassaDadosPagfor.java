package br.com.hdi.pagfor.repository;

import br.com.hdi.pagfor.valueobject.*;

import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MassaDadosPagfor {
	
	public Connection cnx;
	public void ConectSqlServer() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException
	{
		String dbConnectionStringPrivate = "jdbc:sqlserver://ALPF-DL-L1CB19G\\SERVER_01:1433;databaseName=STARC;";
		
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
		cnx = DriverManager.getConnection(dbConnectionStringPrivate,"sa", "Cielo2017");
	}
	
	
	public ArrayList<PagforValueObject> RetornaPAGFOR() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException
	{
		Statement statement;
		ResultSet resultSet;
		ArrayList<PagforValueObject> array = new ArrayList<PagforValueObject>();
		
		ConectSqlServer();
		
		try
		{
			statement = cnx.createStatement();
			resultSet = statement.executeQuery("SELECT * FROM TbMassaBaixaArquivoPagfor");
			
			while(resultSet.next())
			{
				array.add(new PagforValueObject(
						resultSet.getInt("ID"), 
						resultSet.getString("DsNomeArquivo"), 
						resultSet.getInt("NuVersaoArquivo"), 
						resultSet.getString("DsDiretorioArquivo")
				));	
			}
			return array;
		}
		catch(Exception excp)
		{
			return null;
		}
		
	}
	

}
